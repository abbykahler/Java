public class BatTest {
    public static void main(String args[]){
        Bat ba = new Bat();
        ba.displayEnergy();
        ba.attackTown();
        ba.attackTown();
        ba.attackTown();
        ba.displayEnergy();
        ba.eatHumans();
        ba.eatHumans();
        ba.displayEnergy();
        ba.fly();
        ba.fly();
        ba.displayEnergy();
    }
}

