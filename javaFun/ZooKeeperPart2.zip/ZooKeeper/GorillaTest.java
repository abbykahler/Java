public class GorillaTest {
    public static void main(String args[]){
        Gorilla gor = new Gorilla();
        gor.displayEnergy();
        gor.throwSomething();
        gor.throwSomething();
        gor.throwSomething();
        gor.displayEnergy();
        gor.eatBananas();
        gor.eatBananas();
        gor.displayEnergy();
        gor.climb();
        gor.displayEnergy();
    }
}